package org.bukkit.entity;

/**
 * Represents a wither skull {@link Fireball}
 */
public interface WitherSkull extends Fireball {

}
