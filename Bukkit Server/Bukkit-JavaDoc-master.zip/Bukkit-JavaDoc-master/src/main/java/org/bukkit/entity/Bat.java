package org.bukkit.entity;

/**
 * Represents a Bat
 */
public interface Bat extends Ambient {}
