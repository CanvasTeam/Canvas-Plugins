package org.bukkit.entity;

/**
 * Represents a non-player character
 */
public interface NPC extends Creature {

}
