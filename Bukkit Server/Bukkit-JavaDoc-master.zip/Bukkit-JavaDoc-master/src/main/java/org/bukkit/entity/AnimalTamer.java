package org.bukkit.entity;

public interface AnimalTamer {
    /**
     * This is the name of the specified AnimalTamer.
     * @return The name to reference on tamed animals
     */
    public String getName();
}
