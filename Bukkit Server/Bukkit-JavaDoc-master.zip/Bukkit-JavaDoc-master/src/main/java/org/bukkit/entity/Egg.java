package org.bukkit.entity;

/**
 * Represents a thrown egg.
 */
public interface Egg extends Projectile {}
